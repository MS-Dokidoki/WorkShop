name = "lesson network"
author = "LongFei"
description = [[
网络编程教学例 教你如何使用netvar和RPC

Network Tutorial Example for netvar and RPC
]]
version = "1.0.0"
dst_compatible = true
forge_compatible = false
gorge_compatible = false
dont_starve_compatible = false
client_only_mod = false
all_clients_require_mod = true
--icon_atlas = "modicon.xml"
--icon = "modicon.tex"
forumthread = ""
api_version_dst = 10
priority = 0
mod_dependencies = {}
server_filter_tags = {}





