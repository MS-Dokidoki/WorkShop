name = "饥荒Mod入门_脚手架"
author = "LongFei"
version = "V0.0.1 S"
description = "饥荒Mod入门-脚手架，请参照文章完成作业\n\n本教程的美术资源仅供教学使用\n请勿用于自己发布的Mod"

forumthread = ""
api_version = 10

dst_compatible = true
all_clients_require_mod = true


icon_atlas = "modicon.xml"
icon = "modicon.tex"
