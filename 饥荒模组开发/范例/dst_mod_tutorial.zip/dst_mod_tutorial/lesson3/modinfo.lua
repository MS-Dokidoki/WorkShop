--[[	Copyright © 2015 Ultroman	 ]]
name = "IronHand"
description = "make you can work without tool"
author = "LongFei"
version = "0.0.1"

forumthread = ""
api_version = 10

dst_compatible = true

dont_starve_compatible = false
reign_of_giants_compatible = false
shipwrecked_compatible = false

all_clients_require_mod = true 

server_filter_tags = {}

priority = 0

icon_atlas = "modicon.xml"
icon = "modicon.tex"

