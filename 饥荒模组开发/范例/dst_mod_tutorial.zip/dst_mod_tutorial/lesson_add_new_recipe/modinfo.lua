name = "饥荒Mod教程_添加配方"
author = "LongFei"
version = "1.0"
description = "饥荒Mod教程_添加配方\n\n关于新版制作栏下添加配方的全面教程\n\n本教程的美术资源仅供教学使用\n请勿用于自己发布的Mod"

forumthread = ""
api_version = 10

dst_compatible = true
all_clients_require_mod = true
